package models;

/**
 * Created by TRANG TRUONG on 6/14/2017.
 */

public class Login {
    private static String autoName = "user";
    private static String autoPW = "pw";
    private static String name;
    private static String pw;

    public Login(String name, String pw) {
        this.name = name;
        this.pw = pw;
    }

    public static boolean checkLogin() {
        return name.equals(autoName) && pw.equals(autoPW);
    }
}
