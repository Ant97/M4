package models;

/**
 * Created by TRANG TRUONG on 6/14/2017.
 */

public class Registration {
    private static String[] list = new String[10];
    private static int count = 0;

    public Registration(String name) {
        list[count] = name;
        count++;
    }

    public static boolean checkRegister(String pw, String pw1) {
        return pw.equals(pw1);
    }

    public static String[] getList() {
        return list;
    }


}
