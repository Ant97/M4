package com.example.trangtruong.m4.controllers;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.trangtruong.m4.R;

import models.Login;
import models.Registration;

public class LoginScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);

        final EditText loginName = (EditText) findViewById(R.id.loginName);
        final EditText loginPW = (EditText) findViewById(R.id.loginPW);

        final Button login = (Button) findViewById(R.id.login);
        final Button cancel1 = (Button) findViewById(R.id.cancel1);
        final TextView checkLogin = (TextView) findViewById(R.id.checkLogin);

        cancel1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent cancel1Intent = new Intent(LoginScreen.this, WelcomeScreen.class);
                LoginScreen.this.startActivity(cancel1Intent);
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String name = loginName.getText().toString();
                final String pw = loginPW.getText().toString();

                Login login = new Login(name, pw);

                if (Login.checkLogin()) {
                    Intent loginIntent = new Intent(LoginScreen.this, sLogin.class);
                    LoginScreen.this.startActivity(loginIntent);
                } else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(LoginScreen.this);
                    builder.setMessage("Login Failed")
                            .setNegativeButton("Retry", null)
                            .create()
                            .show();
                    checkLogin.setText("Username or PW incorrect");
                }
            }
        });
    }
}
