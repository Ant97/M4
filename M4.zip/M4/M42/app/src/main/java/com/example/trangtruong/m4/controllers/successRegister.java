package com.example.trangtruong.m4.controllers;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.trangtruong.m4.R;

public class successRegister extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_success_register);
    }
}
