package com.example.trangtruong.m4.controllers;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.trangtruong.m4.R;

import models.Registration;

/**
 * This is controller for Register Screen
 * @author AnT. & Annette
 * @version 1.0
 */

public class RegisterScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_screen);

        final EditText registerName =
                (EditText) findViewById(R.id.registerName);
        final EditText registerUsername =
                (EditText) findViewById(R.id.registerUserName);
        final EditText registerPW =
                (EditText) findViewById(R.id.registerPW);
        final EditText registerPW1 =
                (EditText) findViewById(R.id.registerPW1);

        final Button register = (Button) findViewById(R.id.register1);
        final Button cancel2 = (Button) findViewById(R.id.cancel2);

        cancel2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent cancel2Intent =
                        new Intent(RegisterScreen.this, WelcomeScreen.class);
                RegisterScreen.this.startActivity(cancel2Intent);
            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String name = registerName.getText().toString();
                final String username = registerUsername.getText().toString();
                final String pw = registerPW.getText().toString();
                final String pw1 = registerPW1.getText().toString();

                Registration register = new Registration(name);

                if (Registration.checkRegister(pw, pw1)) {
                    AlertDialog.Builder builder =
                            new AlertDialog.Builder(RegisterScreen.this);
                    builder.setMessage("Register Successful")
                            .setNegativeButton("Retry", null)
                            .create().show();
                    Intent registerIntent =
                            new Intent(RegisterScreen.this, LoginScreen.class);
                    RegisterScreen.this.startActivity(registerIntent);
                } else {
                    AlertDialog.Builder builder =
                            new AlertDialog.Builder(RegisterScreen.this);
                    builder.setMessage("Register Failed")
                            .setNegativeButton("Retry", null)
                            .create().show();
                }
            }
        });
    }
}
